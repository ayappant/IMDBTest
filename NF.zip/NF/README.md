This solution contains the sample test for verifying the web page "IMDB top 250 movies"

-Solution has been implemented using Selenium Web Driver
-Have used C# as the programming language
-All the dependent libraries like Selenium, WebSupport has been referenced through NuGet Package
-Have used NUnit Framework as the testing Framework
-This has been developed using .NET Framework 4.0 and its corresponding dlls are required in the local machine.